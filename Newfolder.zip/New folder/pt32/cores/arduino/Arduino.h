// This file intentionally left blank
// See: https://arduino.github.io/arduino-cli/dev/platform-specification/#cores
