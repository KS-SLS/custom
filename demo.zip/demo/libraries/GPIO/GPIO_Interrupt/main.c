/**
  ******************************************************************************
  * @file    Project/PT32x031_StdPeriph_Templates/main.c 
  * @author  Ӧ�ÿ����Ŷ�
  * @version V1.0.0
  * @date    2020/04/28
  * @brief   Main ������
  ******************************************************************************
  * @attention
  *
  * 
  *
  * 
  * 
  * 
  *
  * 
  *
  * 
  * 
  * 
  * 
  * 
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup PT32x031_StdPeriph_Templates
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{

  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_pt32f0xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_pt32f0xx.c file
     */ 
      
  /* Add your application code here
     */
	/* */
  NVIC_InitTypeDef NVIC_InitStruct;
  GPIO_InitTypeDef  GPIO_InitStruct;	
  NVIC_InitStruct.NVIC_IRQChannel = PA_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPriority = 0x00;
	NVIC_Init(&NVIC_InitStruct);
	/*����PA11���ж�����Ϊ�½��ش���*/
	GPIO_TriTypeConfig(CMSDK_PA, GPIO_Pin_11, GPIOTI_Trigger_Falling);
  /*ʹ��PA11�ܽŵ��ж�*/
	GPIO_ITConfig(CMSDK_PA, GPIO_IT_ITE11, ENABLE);
	/*����PB5Ϊ�����������LEDָʾ�� */
	GPIO_InitStruct.GPIO_Mode = GPIO_OType_OD;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_5;
  GPIO_Init(CMSDK_PB, &GPIO_InitStruct);
	
//	GPIO_LowByte_WriteBit(CMSDK_PB, GPIO_Pin_4 , 1);
  /* Infinite loop */
  while (1)
  {
	/*������GPIO���ж��ڷ�תPB5״̬����LED�Ƶ���˸*/
  }
}


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */


/************************ (C) COPYRIGHT PENGPAI Microelectronics *****END OF FILE****/
