#ifndef VARIANT_H
#define VARIANT_H

// Define any additional configuration or macros here
// You can leave this file empty for a basic setup

#endif
