#include "PT32X031.h"
#include "PT32x031_GPIO.h"

uint32_t GetGPIOpin(uint8_t pin);
//  PT32x031:: PT32x031(uint8_t pin) {
//     _pin = pin;
// }

// void  PT32x031::begin() {
//     pinMode(_pin, OUTPUT);
// }

// void  PT32x031::setLED(bool state) {
//     digitalWrite(_pin, state);
// }



// void GPIO_Config(void) {
//   GPIO_InitTypeDef GPIO_InitStructure;
//   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
//   GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
//   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
//   GPIO_Init(CMSDK_PB, &GPIO_InitStructure);
// }

void pinMode(uint8_t pinNumber, uint8_t mode) {
 uint8_t pin = GetGPIOpin(pinNumber);
  GPIO_InitTypeDef GPIO_InitStruct;
  GPIO_InitStruct.GPIO_Pin = pin;
  switch (mode) {
      case 0:
          GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
          break;
      case 1:
          GPIO_InitStruct.GPIO_Mode = GPIO_OType_PP;
          break;
      case 2:
          GPIO_InitStruct.GPIO_Mode = GPIO_OType_OD;
          break;
      case 3:
          GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
          break;
  }
  GPIO_Init(CMSDK_PB, &GPIO_InitStruct);
}
// void digitalRead(uint8_t CMSDK_Px, uint8_t GPIO_Pin) {
//     GPIO_ReadInputDataBit(CMSDK_Px, GPIO_Pin);
// }

void digitalRead(CMSDK_GPIO_TypeDef* CMSDK_Px, uint8_t GPIO_Pin) {
    GPIO_ReadInputDataBit(CMSDK_Px, GPIO_Pin);
}



// void GPIO_Init(CMSDK_GPIO_TypeDef* CMSDK_Px, GPIO_InitTypeDef* GPIO_Pin) {
//   assert_param(IS_GPIO_ALL_PERIPH(CMSDK_Px));
//   assert_param(IS_GPIO_PIN(GPIO_InitStruct->GPIO_Pin));
// }

uint32_t GetGPIOpin(uint8_t pin) {
  if (pin == 0) {
    return GPIO_Pin_0;
  } else if (pin == 1) {
    return GPIO_Pin_1;
  } else if (pin == 2) {
    return GPIO_Pin_2;
  } else if (pin == 3) {
    return GPIO_Pin_3;
  } else if (pin == 4) {
    return GPIO_Pin_4;
  } else if (pin == 5) {
    return GPIO_Pin_5;
  } else if (pin == 6) {
    return GPIO_Pin_6;
  } else if (pin == 7) {
    return GPIO_Pin_7;
  } else if (pin == 8) {
    return GPIO_Pin_8;
  } else if (pin == 9) {
    return GPIO_Pin_9;
  } else if (pin == 10) {
    return GPIO_Pin_10;
  } else if (pin == 11) {
    return GPIO_Pin_11;
  } else if (pin == 12) {
    return GPIO_Pin_12;
  } else if (pin == 13) {
    return GPIO_Pin_13;
  } else if (pin == 14) {
    return GPIO_Pin_14;
  } else if (pin == 15) {
    return GPIO_Pin_15;
  }
}

void digitalWrite(uint8_t pin, uint8_t val) {
  CMSDK_GPIO_TypeDef* port;
  // uint32_t pt32pin;

  if (pin < 16) {
    port = CMSDK_PA;
    // pt32pin = GetGPIOpin(pin);
  } else if (pin > 16 && pin <= 24) {
    port = CMSDK_PB;
    // pt32pin = pin - 16;
  } else if (pin > 25 && pin <= 32) {
    port = CMSDK_PF;
    // pt32pin = pin - 24;
  }
uint8_t pinNumber2 =GetGPIOpin( pin );
  if (val==HIGH) {
    GPIO_SetBits(port, pinNumber2);
  } else {
    GPIO_ResetBits(port, pinNumber2);
  }
}
