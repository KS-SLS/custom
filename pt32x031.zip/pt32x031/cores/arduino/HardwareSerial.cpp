/*
  HardwareSerial.cpp - Hardware serial library for Wiring
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Modified 23 November 2006 by David A. Mellis
  Modified 28 September 2010 by Mark Sproul
  Modified 14 August 2012 by Alarus
  Modified 3 December 2013 by Matthijs Kooijman
*/

// #include "Arduino.h"
// #include "pt32x031.h"
#include "HardwareSerial.h"
#include "ee_printf.h"
// #include "pt32x031_gpio.h"
// #include "pt32x031_it.c"
#include "pt32x031_misc.h"
// #include "pt32x031_it.h"
#include "main.h"
#include "pt32x031_spi.h"
// #include "bsp_spi_flash.h"

class HardwareSerial Serial1;
class SPIClass SPI;

// uint16_t spi_slave_TxLen = 0;
// uint16_t spi_slave_TxIndex = 0;
// uint16_t spi_master_TxLen = 0;
// uint16_t spi_master_TxIndex = 0;
// uint8_t master_spi_RxComplete = 0;
// uint8_t slave_spi_RxComplete = 0;
// uint8_t master_spi_txBuf[DEMO_SPI_BUFFERSIZE];
// uint8_t master_spi_RxBuf[DEMO_SPI_BUFFERSIZE];
// uint8_t slave_spi_txBuf[DEMO_SPI_BUFFERSIZE];
// uint8_t slave_spi_RxBuf[DEMO_SPI_BUFFERSIZE];

// typedef enum { FAILED = 0, PASSED = !FAILED} TestStatus;

void HardwareSerial::begin(uint32_t baud)
{

  UART_InitTypeDef UART_InitStruct;
  // LED_GPIO_Config();
  /*����PB6����ΪUART0_TX,PA15����ΪUART0_RX*/
  GPIO_PinAFConfig(CMSDK_PB, GPIO_PinSource6, GPIO_AF_3);
  GPIO_PinAFConfig(CMSDK_PA, GPIO_PinSource15, GPIO_AF_3);
  /*��ʼ��UART0*/
  UART_InitStruct.UART_BaudRate = baud;
  UART_InitStruct.UART_WordLength = UARTM_8D_W;
  UART_InitStruct.UART_StopBit = UART1StopBit;
  UART_InitStruct.UART_Parity = UART_EVEN_PARITY;
  UART_InitStruct.UART_RXEN = ENABLE;
  UART_InitStruct.UART_SampleRate = UART_SAMPLERATEX4;
  UART_Init(UART0, &UART_InitStruct);
  /*����UART0���շ�����*/
  UART_Cmd(UART0, ENABLE);
  /* Infinite loop */
  // Show_Message();
}

void HardwareSerial::print(const char c[])
{
  // Implement the print function using ee_printf

  ee_printf("%s", c);
}

// uint16_t HardwareSerial::println() {
//   // Serial1.println();
//  return SERIAL_GetChar();
// }
uint16_t SERIAL_GetChar(void)
{

  while ((UART0->SR & UART_ISR_RXNE) == 0)
    ; // Wait if Receive Holding register is empty
  return (UART0->BR);
}

void HardwareSerial::println(char vari)
{
  //   Serial1.println();
  // }
  ee_printf("%s", vari);
  // uint16_t SERIAL_GetChar(void) {
  //   while ((UART0->SR & UART_ISR_RXNE) == 0); // Wait if Receive Holding register is empty
  //   return (UART0->DR & 0xFF); // Read and return the received character
}

void HardwareSerial::println(uint8_t vari)
{
  ee_printf("%d", vari);
}

void HardwareSerial::println(uint16_t vari)
{
  ee_printf("%d\r\n", vari);
}

// void HardwareSerial::println(const char* str) {
//   ee_printf("%s", str);
// }

void HardwareSerial::println(const char *str)
{
  if (str)
  {
    ee_printf("%s\n", str); // Print the string followed by a newline
  }
  else
  {
    ee_printf("NULL string\n"); // Handle null string case
  }
}

uint16_t HardwareSerial::read(void)
{
  // Wait until a character is available
  // while ((UART0->SR & UART_ISR_RXNE) == 0); // Wait if Receive Holding register is empty

  // Read the character from the UART buffer
  // uint16_t receivedChar = SERIAL_GetChar();

  // Convert the received character to an integer and return it
  return SERIAL_GetChar();
}

// int HardwareSerial::read(void)
// {
//    int read_val = SERIAL_GetChar();
//    return read_val;
//   // if the head isn't ahead of the tail, we don't have any characters;
// }

// int HardwareSerial::availableForWrite(void) {
//     ee_printf("%x", data);
//   // return 0;
// }

int HardwareSerial::available(void)
{
  return 1;
  // return Serial1.available();
}

size_t HardwareSerial::write(uint8_t)
{
  // Implementation of the write function
  return 1; // Placeholder return value
}

void HardwareSerial::end()
{
  // wait for transmission of outgoing data
  flush();
}

void HardwareSerial::flush(void)
{
  // wait for transmission of outgoing data
  // flush();
}

// int HardwareSerial::peek(void)
// {

// }

// }

// #include "main.h"

/** @addtogroup PT32x031_StdPeriph_Templates
 * @{
 */

void LED_GPIO_Config(void)
{
  /*����һ��GPIO_InitTypeDef���͵Ľṹ��*/
  GPIO_InitTypeDef GPIO_InitStructure;
  /*ѡ��Ҫ���Ƶ�GPIO����*/
  GPIO_InitStructure.GPIO_Pin = LED1_GPIO_PIN;

  /*��������ģʽΪͨ���������*/
  GPIO_InitStructure.GPIO_Mode = GPIO_OType_PP;

  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;

  /*���ÿ⺯������ʼ��GPIO*/
  GPIO_Init(LED1_GPIO_PORT, &GPIO_InitStructure);

  /*ѡ��Ҫ���Ƶ�GPIO����*/
  GPIO_InitStructure.GPIO_Pin = LED2_GPIO_PIN;

  /*���ÿ⺯������ʼ��GPIO*/
  GPIO_Init(LED2_GPIO_PORT, &GPIO_InitStructure);

  /*ѡ��Ҫ���Ƶ�GPIO����*/
  GPIO_InitStructure.GPIO_Pin = LED3_GPIO_PIN;

  /*���ÿ⺯������ʼ��GPIO*/
  GPIO_Init(LED3_GPIO_PORT, &GPIO_InitStructure);

  /* �ر�����led��	*/
  GPIO_SetBits(LED1_GPIO_PORT, LED1_GPIO_PIN);

  /* �ر�����led��	*/
  GPIO_SetBits(LED2_GPIO_PORT, LED2_GPIO_PIN);

  /* �ر�����led��	*/
  GPIO_SetBits(LED3_GPIO_PORT, LED3_GPIO_PIN);

  /*����һ��GPIO_InitTypeDef���͵Ľṹ��*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(CMSDK_PB, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(CMSDK_PB, &GPIO_InitStructure);
}

/**
 * @brief  UART GPIO ����,������������
 * @param  ��
 * @retval ��
 */
void UART_Config(void)
{
  UART_InitTypeDef UART_InitStruct;
  /*����PB6����ΪUART0_TX,PA15����ΪUART0_RX*/
  GPIO_PinAFConfig(CMSDK_PB, GPIO_PinSource6, GPIO_AF_3);
  GPIO_PinAFConfig(CMSDK_PA, GPIO_PinSource15, GPIO_AF_3);
  /*��ʼ��UART0*/
  UART_InitStruct.UART_BaudRate = 19200;
  UART_InitStruct.UART_WordLength = UARTM_8D;
  UART_InitStruct.UART_StopBit = UART1StopBit;
  UART_InitStruct.UART_Parity = UART_ODD_PARITY;
  UART_InitStruct.UART_RXEN = ENABLE;
  UART_InitStruct.UART_SampleRate = UART_SAMPLERATEX16;
  UART_Init(UART0, &UART_InitStruct);
  /*����UART0���շ�����*/
  UART_Cmd(UART0, ENABLE);
}

// void HardwareSerial::flush()

SPIClass::SPIClass()
{
  // Initialization, if needed
}

// Method to begin SPI
void SPIClass::begin()
{
  // Here, we assume you are initializing the SPI as master by default
  // You can modify this to select between master and slave if needed
  SPI_Master_Init(SPI0); // Assuming SPIx is defined somewhere in your code
  SPI_Slave_Init(SPI1);
}

void Delay(__IO uint32_t nCount)
{
  for (; nCount != 0; nCount--)
    ;
}

// Method to initialize SPI as master
void SPIClass::SPI_Master_Init(CMSDK_SPI_TypeDef *SPIx)
{
  SPI_InitTypeDef SPI_InitStructure;
  NVIC_InitTypeDef NVIC_InitStruct;

#ifdef SPIMASTER_GPIO_CS
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin = MASTER_SPI_CS_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(MASTER_SPI_CS_PORT, &GPIO_InitStructure);
#else
  GPIO_PinAFConfig(MASTER_SPI_CS_PORT, MASTER_SPI_CS_PINSOURCE, GPIO_AF_0); // CS as hardware automatic mode
#endif
  GPIO_PinAFConfig(MASTER_SPI_SCK_PORT, MASTER_SPI_SCK_PINSOURCE, GPIO_AF_0);
  GPIO_PinAFConfig(MASTER_SPI_MISO_PORT, MASTER_SPI_MISO_PINSOURCE, GPIO_AF_0);
  GPIO_PinAFConfig(MASTER_SPI_MOSI_PORT, MASTER_SPI_MOSI_PINSOURCE, GPIO_AF_0);

  // NVIC_InitStruct.NVIC_IRQChannel = DEMO_master_SPIx_IRQn;
  // NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
  // NVIC_InitStruct.NVIC_IRQChannelPriority = 0x00;
  // NVIC_Init(&NVIC_InitStruct);

  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_CR0_DSS_8B;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;
  SPI_InitStructure.SPI_BaudRatePrescaler = 60;
  SPI_InitStructure.SPI_BaudRatePostPrescaler = 0;
  SPI_Init(SPIx, &SPI_InitStructure);

  // SPI_ClearFlag(SPIx, SPI_IT_RFNEOT);
  // SPI_ITConfig(SPIx, SPI_IT_RFNEOT, ENABLE);
  // SPI_ITConfig(SPIx, SPI_IT_RFHF, ENABLE);
  SPI_Cmd(SPIx, ENABLE);
}

// Method to initialize SPI as slave
void SPIClass::SPI_Slave_Init(CMSDK_SPI_TypeDef *SPIx)
{
  NVIC_InitTypeDef NVIC_InitStruct;
  SPI_InitTypeDef SPI_InitStructure;

  GPIO_PinAFConfig(SLAVE_SPI_CS_PORT, SLAVE_SPI_CS_PINSOURCE, GPIO_AF_1);
  GPIO_PinAFConfig(SLAVE_SPI_SCK_PORT, SLAVE_SPI_SCK_PINSOURCE, GPIO_AF_1);
  GPIO_PinAFConfig(SLAVE_SPI_MISO_PORT, SLAVE_SPI_MISO_PINSOURCE, GPIO_AF_1);
  GPIO_PinAFConfig(SLAVE_SPI_MOSI_PORT, SLAVE_SPI_MOSI_PINSOURCE, GPIO_AF_1);

  // NVIC_InitStruct.NVIC_IRQChannel = DEMO_slave_SPIx_IRQn;
  // NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
  // NVIC_InitStruct.NVIC_IRQChannelPriority = 0x00;
  // NVIC_Init(&NVIC_InitStruct);

  SPI_InitStructure.SPI_Mode = SPI_Mode_Slave;
  SPI_InitStructure.SPI_DataSize = SPI_CR0_DSS_8B;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;
  SPI_InitStructure.SPI_BaudRatePrescaler = 16;
  SPI_InitStructure.SPI_BaudRatePostPrescaler = 0;
  SPI_Init(SPIx, &SPI_InitStructure);

  // SPI_ClearFlag(SPIx, SPI_IT_RFNEOT);
  // SPI_ITConfig(SPIx, SPI_IT_RFNEOT, ENABLE);
  // SPI_ITConfig(SPIx, SPI_IT_RFHF, ENABLE);
  SPI_Cmd(SPIx, ENABLE);
}




// int Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
// {
//   while(BufferLength--)
//   {
//     if(*pBuffer1 != *pBuffer2)
//     {
//       return 0;
//     }

//     pBuffer1++;
//     pBuffer2++;
//   }
//   return 1;
// }




uint8_t SPIClass::transfer(uint16_t data)
{
SPI_SendData(SPI1, data);
return data;
}









// int Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength) {
//   while (BufferLength--) {
//     if (*pBuffer1 != *pBuffer2) {
//       return 0;
//     }
//     pBuffer1++;
//     pBuffer2++;
//   }
//   return 1;
// }

// Function to perform the SPI transaction and buffer comparison
void performSpiTransaction(uint8_t Data) {
  SPI_SendData(SPI0,  Data);
  // for (volatile uint32_t i = 0; i < 1200; i++) {
  //   // Delay loop
  // }

  // master_spi_RxComplete = false;
  // slave_spi_RxComplete = false;

  // digitalWrite(3, LOW);

  // for (int i = 0; i < DEMO_SPI_BUFFERSIZE; i++) {
  //   master_spi_RxBuf[i] = SPI.transfer(master_spi_txBuf[i]);
  // }

  // digitalWrite(3, HIGH);

  // master_spi_RxComplete = true;
  // Serial1.print("PASSED");

  // if (master_spi_RxComplete) {
  //   int retval = Buffercmp(master_spi_txBuf, slave_spi_RxBuf, DEMO_SPI_BUFFERSIZE);
  //   if (retval == 1) {
  //     Serial1.print("PASSED");
  //     digitalWrite(LED2_PIN, LOW);
  //     digitalWrite(LED3_PIN, HIGH);
  //   } else {
  //     Serial1.print("FAILED");
  //     digitalWrite(LED3_PIN, LOW);
  //     digitalWrite(LED2_PIN, HIGH);
  //   }
  // }
}
