#include "stdint.h"
#include "pt32x031_adc.h"
 
 
uint16_t adc_read_value(void) {
	uint16_t coversion_value;
	ADC_InitTypeDef  ADC_InitStruct;
	ADC_InitStruct.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_Software;
	ADC_InitStruct.ADC_HighSpeedSampMode = ENABLE;
 
	ADC_Init(ADC, &ADC_InitStruct);
	ADC->TRSTN |= 0x00000001;
	ADC_ClockModeConfig(ADC, ADC_ClockMode_SynClkDiv8);
	ADC_ChannelConfig(ADC, ADC_Channel_11);
	ADC_Cmd(ADC, ENABLE);
	while(!ADC_GetFlagStatus(ADC,ADC_FLAG_ADRDY));
	while(!ADC_GetFlagStatus(ADC,ADC_FLAG_EOC));
	ADC_ClearFlag(ADC,ADC_FLAG_EOC);
	coversion_value = ADC_GetConversionValue(ADC);
	return coversion_value;
}

 
 
uint32_t analogRead(void)
{
  uint32_t value = 0;
  value = adc_read_value();
  return value;
}