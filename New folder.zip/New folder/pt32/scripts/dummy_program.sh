#!/bin/sh
# A dummy executable to give the compiler recipes in platform.txt something to run
