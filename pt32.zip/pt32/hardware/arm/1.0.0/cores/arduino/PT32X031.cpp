#include "pt32x031.h"
#include "PT32x031_GPIO.h"
#include "ee_printf.h"
#include "pt32x031_uart.h"
#include "pt32x031_serial.h"


#ifndef LOW
#define LOW 0
#endif

#ifndef HIGH
#define HIGH 1
#endif

#ifndef INPUT
#define INPUT LOW
#endif
#ifndef OUTPUT
#define OUTPUT HIGH
#endif
// #define HIGH  1
// #define LOW   0
 uint32_t GetGPIOpin(uint8_t pin);
//  PT32x031:: PT32x031(uint8_t pin) {
//     _pin = pin;
// }

// void  PT32x031::begin() {
//     pinMode(_pin, OUTPUT);
// }

// void  PT32x031::setLED(bool state) {
//     digitalWrite(_pin, state);
// }



void GPIO_Config(void) {
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_Init(CMSDK_PB, &GPIO_InitStructure);
}

void pinMode(uint8_t pinNumber, uint8_t mode) {
 uint8_t pin = GetGPIOpin(pinNumber);
  GPIO_InitTypeDef GPIO_InitStruct;
  GPIO_InitStruct.GPIO_Pin = pin;
  switch (mode) {
      case INPUT:
          GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
          break;
      case OUTPUT:
          GPIO_InitStruct.GPIO_Mode = GPIO_OType_PP;
          break;
      case 2:
          GPIO_InitStruct.GPIO_Mode = GPIO_OType_OD;
          break;
      case 3:
          GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
          break;
  }
  GPIO_Init(CMSDK_PB, &GPIO_InitStruct);
}
// void digitalRead(uint8_t CMSDK_Px, uint8_t GPIO_Pin) {
//     GPIO_ReadInputDataBit(CMSDK_Px, GPIO_Pin);
// }

void digitalRead(CMSDK_GPIO_TypeDef* CMSDK_Px, uint8_t GPIO_Pin) {
    GPIO_ReadInputDataBit(CMSDK_Px, GPIO_Pin);
}



// void GPIO_Init(CMSDK_GPIO_TypeDef* CMSDK_Px, GPIO_InitTypeDef* GPIO_Pin) {
//   assert_param(IS_GPIO_ALL_PERIPH(CMSDK_Px));
//   assert_param(IS_GPIO_PIN(GPIO_InitStruct->GPIO_Pin));
// }

uint32_t GetGPIOpin(uint8_t pin) {
  if (pin == 0) {
    return GPIO_Pin_0;
  } else if (pin == 1) {
    return GPIO_Pin_1;
  } else if (pin == 2) {
    return GPIO_Pin_2;
  } else if (pin == 3) {
    return GPIO_Pin_3;
  } else if (pin == 4) {
    return GPIO_Pin_4;
  } else if (pin == 5) {
    return GPIO_Pin_5;
  } else if (pin == 6) {
    return GPIO_Pin_6;
  } else if (pin == 7) {
    return GPIO_Pin_7;
  } else if (pin == 8) {
    return GPIO_Pin_8;
  } else if (pin == 9) {
    return GPIO_Pin_9;
  } else if (pin == 10) {
    return GPIO_Pin_10;
  } else if (pin == 11) {
    return GPIO_Pin_11;
  } else if (pin == 12) {
    return GPIO_Pin_12;
  } else if (pin == 13) {
    return GPIO_Pin_13;
  } else if (pin == 14) {
    return GPIO_Pin_14;
  } else if (pin == 15) {
    return GPIO_Pin_15;
  }
}

void digitalWrite(uint8_t pin, uint8_t val) {
  CMSDK_GPIO_TypeDef* port;
  // uint32_t pt32pin;

  if (pin < 16) {
    port = CMSDK_PA;
    // pt32pin = GetGPIOpin(pin);
  } else if (pin > 16 && pin <= 24) {
    port = CMSDK_PB;
    // pt32pin = pin - 16;
  } else if (pin > 25 && pin <= 32) {
    port = CMSDK_PF;
    // pt32pin = pin - 24;
  }
uint8_t pinNumber2 =GetGPIOpin( pin );
  if (val== HIGH) {
    GPIO_SetBits(port, pinNumber2);
  } else {
    GPIO_ResetBits(port, pinNumber2);
  }
}


// void begin_HardwareSerial(uint32_t baudrate) {

//   UART_InitTypeDef UART_InitStruct;
//   //  LED_GPIO_Config(); 
//   /* Configure PB6 as UART0_TX and PA15 as UART0_RX */
//   GPIO_PinAFConfig(CMSDK_PB, GPIO_PinSource6, GPIO_AF_3);
//   GPIO_PinAFConfig(CMSDK_PA, GPIO_PinSource15, GPIO_AF_3);
//   /* Initialize UART0 */
//   UART_InitStruct.UART_WordLength = 19200;
//   UART_InitStruct.UART_WordLength = UARTM_8D_W;
//   UART_InitStruct.UART_StopBit = UART1StopBit;
//   UART_InitStruct.UART_Parity = UART_EVEN_PARITY; 
//   UART_InitStruct.UART_RXEN = ENABLE;
//   UART_InitStruct.UART_SampleRate = UART_SAMPLERATEX4;
//   UART_Init(UART0, &UART_InitStruct);
//   /* Enable UART0 receiver */
//   UART_Cmd(UART0, ENABLE);
//   /* Infinite loop */
//   // Show_Message();

// }


// void end_HardwareSerial() {
//   // Your cleanup code here

// }

// uint8_t available_HardwareSerial() {
//   // Your code to check for available data in the receive buffer
//   return 2; // Placeholder, replace with actual implementation
// }






// void HardwareSerial::end() {
//   // Your cleanup code here
  
// }

// uint8_t HardwareSerial::available() {
//   // Your code to check for available data in the receive buffer
//   return 2; // Placeholder, replace with actual implementation
// }


// int HardwareSerial::read() {
// //   // Your code to read data from the receive buffer
//      read_val = SERIAL_GetChar();
// // uint16_t SERIAL_GetChar(void)
// // {

// //   while ((UART0->SR & UART_ISR_RXNE)==0); // Wait if Receive Holding register is empty
// //   return (UART0->BR);
// // }
// //   int chara= SERIAL_GetChar();
//    return read_val(); // Placeholder, replace with actual implementation
// // }


// void HardwareSerial::flush() {
//   // Your code to flush the transmit buffer
// }


// // Other methods...

// void HardwareSerial::print(const char* str) {
//   while (*str) {
//     write(*str++);
//   }
// }

// void HardwareSerial::print(int num) {
//   char buffer[12]; // Assuming a maximum of 12 characters for the integer representation
//   itoa(num, buffer, 10);
//   ee_printf(buffer);
// }

// void HardwareSerial::print(unsigned int num) {
//   char buffer[12]; // Assuming a maximum of 12 characters for the integer representation
//   itoa(num, buffer, 10);
//   ee_printf(buffer);
// }

// void HardwareSerial::print(long num) {
//   char buffer[12]; // Assuming a maximum of 12 characters for the integer representation
//   ltoa(num, buffer, 10);
//   ee_printf(buffer);
// }

// void HardwareSerial::print(unsigned long num) {
//   char buffer[12]; // Assuming a maximum of 12 characters for the integer representation
//   ultoa(num, buffer, 10);
//   ee_printf(buffer);
// }

// void Serial::print(float num, int decimalPlaces) {
//   // You can implement a function to convert float to string with specified decimal places
// }

// Other print overloads as needed...

// You can also implement other overloads of the print function to support different data types


