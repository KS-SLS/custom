// This is a dummy core.h file
// No content is included as this is a dummy board

