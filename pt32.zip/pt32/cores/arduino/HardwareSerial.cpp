/*
  HardwareSerial.cpp - Hardware serial library for Wiring
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  
  Modified 23 November 2006 by David A. Mellis
  Modified 28 September 2010 by Mark Sproul
  Modified 14 August 2012 by Alarus
  Modified 3 December 2013 by Matthijs Kooijman
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#include <inttypes.h>
// #include <util/atomic.h>
#include "Arduino.h"
#include "pt32x031.h"
#include "HardwareSerial.h"
#include "pt32x031_gpio.h"
#include "ee_printf.h"
 #include "pt32x031_serial.h"

 class HardwareSerial Serial1;
//#include "HardwareSerial_private.h"

// this next line disables the entire HardwareSerial.cpp, 
// this is so I can support Attiny series and any other chip without a uart
// #if defined(HAVE_HWSERIAL0) || defined(HAVE_HWSERIAL1) || defined(HAVE_HWSERIAL2) || defined(HAVE_HWSERIAL3)

// SerialEvent functions are weak, so when the user doesn't define them,
// the linker just sets their address to 0 (which is checked below).
// The Serialx_available is just a wrapper around Serialx.available(),
// but we can refer to it weakly so we don't pull in the entire
// HardwareSerial instance if the user doesn't also refer to it.
// #if defined(HAVE_HWSERIAL0)
//   void serialEvent() __attribute__((weak));
//   bool Serial0_available() __attribute__((weak));
// #endif

// #if defined(HAVE_HWSERIAL1)
//   void serialEvent1() __attribute__((weak));
//   bool Serial1_available() __attribute__((weak));
// #endif

// #if defined(HAVE_HWSERIAL2)
//   void serialEvent2() __attribute__((weak));
//   bool Serial2_available() __attribute__((weak));
// #endif

// #if defined(HAVE_HWSERIAL3)
//   void serialEvent3() __attribute__((weak));
//   bool Serial3_available() __attribute__((weak));
// #endif

// void serialEventRun(void)
// {
// #if defined(HAVE_HWSERIAL0)
//   if (Serial0_available && serialEvent && Serial0_available()) serialEvent();
// #endif
// #if defined(HAVE_HWSERIAL1)
//   if (Serial1_available && serialEvent1 && Serial1_available()) serialEvent1();
// #endif
// #if defined(HAVE_HWSERIAL2)
//   if (Serial2_available && serialEvent2 && Serial2_available()) serialEvent2();
// #endif
// #if defined(HAVE_HWSERIAL3)
//   if (Serial3_available && serialEvent3 && Serial3_available()) serialEvent3();
// #endif
// }

// macro to guard critical sections when needed for large TX buffer sizes
// #if (SERIAL_TX_BUFFER_SIZE>256)
// #define TX_BUFFER_ATOMIC ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
// #else
// #define TX_BUFFER_ATOMIC
// #endif

// Actual interrupt handlers //////////////////////////////////////////////////////////////

// void HardwareSerial::_tx_udr_empty_irq(void)
// {
//   // If interrupts are enabled, there must be more data in the output
//   // buffer. Send the next byte
//   unsigned char c = _tx_buffer[_tx_buffer_tail];
//   _tx_buffer_tail = (_tx_buffer_tail + 1) % SERIAL_TX_BUFFER_SIZE;

//   *_udr = c;

  // clear the TXC bit -- "can be cleared by writing a one to its bit
  // location". This makes sure flush() won't return until the bytes
  // actually got written. Other r/w bits are preserved, and zeroes
  // written to the rest.

// #ifdef MPCM0
//   *_ucsra = ((*_ucsra) & ((1 << U2X0) | (1 << MPCM0))) | (1 << TXC0);
// #else
//   *_ucsra = ((*_ucsra) & ((1 << U2X0) | (1 << TXC0)));
// #endif

//   if (_tx_buffer_head == _tx_buffer_tail) {
//     // Buffer empty, so disable interrupts
//     cbi(*_ucsrb, UDRIE0);
//   }
// }

// Public Methods //////////////////////////////////////////////////////////////





// class HardwareSerial Serial;



void HardwareSerial::begin(uint32_t baud)
{

  UART_InitTypeDef UART_InitStruct;
  // LED_GPIO_Config();	
	/*����PB6����ΪUART0_TX,PA15����ΪUART0_RX*/
  GPIO_PinAFConfig(CMSDK_PB, GPIO_PinSource6, GPIO_AF_3);
  GPIO_PinAFConfig(CMSDK_PA, GPIO_PinSource15, GPIO_AF_3);
	/*��ʼ��UART0*/
  UART_InitStruct.UART_BaudRate = baud;
  UART_InitStruct.UART_WordLength = UARTM_8D_W;
  UART_InitStruct.UART_StopBit = UART1StopBit;
  UART_InitStruct.UART_Parity = UART_EVEN_PARITY; 
  UART_InitStruct.UART_RXEN = ENABLE;
  UART_InitStruct.UART_SampleRate = UART_SAMPLERATEX4;
  UART_Init(UART0, &UART_InitStruct);
	/*����UART0���շ�����*/		
  UART_Cmd(UART0, ENABLE);
  /* Infinite loop */
	// Show_Message();


}

void HardwareSerial::print(const char c[]) {
  // Implement the print function using ee_printf

   ee_printf("%s",c);

}


// uint16_t HardwareSerial::println() {
//   // Serial1.println();
//  return SERIAL_GetChar();
// }
uint16_t SERIAL_GetChar(void)
{

  while ((UART0->SR & UART_ISR_RXNE)==0); // Wait if Receive Holding register is empty
  return (UART0->BR);
}


void HardwareSerial::println( char vari) {
//   Serial1.println();
// }
ee_printf("%s",vari);
// uint16_t SERIAL_GetChar(void) {
//   while ((UART0->SR & UART_ISR_RXNE) == 0); // Wait if Receive Holding register is empty
//   return (UART0->DR & 0xFF); // Read and return the received character
}

void HardwareSerial::println( uint8_t vari) {
  ee_printf("%d",vari);
}



// void HardwareSerial::println(const char* str) {
//   ee_printf("%s", str);
// }


void HardwareSerial::println(const char* str) {
  if (str) {
    ee_printf("%s\n", str); // Print the string followed by a newline
  } else {
    ee_printf("NULL string\n"); // Handle null string case
  }
}


uint16_t HardwareSerial::read(void) {
  // Wait until a character is available
  // while ((UART0->SR & UART_ISR_RXNE) == 0); // Wait if Receive Holding register is empty

  // Read the character from the UART buffer
  // uint16_t receivedChar = SERIAL_GetChar();

  // Convert the received character to an integer and return it
  return SERIAL_GetChar();
}



// int HardwareSerial::read(void)
// {
//    int read_val = SERIAL_GetChar();
//    return read_val;
//   // if the head isn't ahead of the tail, we don't have any characters;
// }

// int HardwareSerial::availableForWrite(void) {
//     ee_printf("%x", data);
//   // return 0;
// }


int HardwareSerial::available(void)
{
  return 1;
  // return Serial1.available();

}

size_t HardwareSerial::write(uint8_t c) {
  // Implementation of the write function
  return 1; // Placeholder return value
}


// int read_HardwareSerial() {
//     // Your code to read data from the receive buffer
//     int read_val = SERIAL_GetChar();
//     return read_val; // Placeholder, replace with actual implementation
// }



// void write_HardwareSerial(uint8_t data) {
//     // Your code to send data
//     ee_printf("%x", data);
// }




void HardwareSerial::end()
{
  // wait for transmission of outgoing data
  flush();

}



// int HardwareSerial::peek(void)
// {

// }


// }





void HardwareSerial::flush()
{
  // If we have never written a byte, no need to flush. This special
  // case is needed since there is no way to force the TXC (transmit
  // complete) bit to 1 during initialization
// Interrupts are globally disabled, but the DR empty
	// interrupt should be enabled, so poll the DR empty flag to
	// prevent deadlock

  // If we get here, nothing is queued anymore (DRIE is disabled) and
  // the hardware finished transmission (TXC is set).
}

// size_t HardwareSerial::write(uint8_t c)
// {
//   // _written = true;
//   // If the buffer and the data register is empty, just write the byte
//   // to the data register and be done. This shortcut helps
//   // significantly improve the effective datarate at high (>
//   // 500kbit/s) bitrates, where interrupt overhead becomes a slowdown.
//   // if (_tx_buffer_head == _tx_buffer_tail && bit_is_set(*_ucsra, UDRE0)) {
//     // If TXC is cleared before writing UDR and the previous byte
//     // completes before writing to UDR, TXC will be set but a byte
//     // is still being transmitted causing flush() to return too soon.
//     // So writing UDR must happen first.
//     // Writing UDR and clearing TC must be done atomically, otherwise
//     // interrupts might delay the TXC clear so the byte written to UDR
//     // is transmitted (setting TXC) before clearing TXC. Then TXC will
//     // be cleared when no bytes are left, causing flush() to hang
// //     ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
// //       *_udr = c;
// // #ifdef MPCM0
// //       *_ucsra = ((*_ucsra) & ((1 << U2X0) | (1 << MPCM0))) | (1 << TXC0);
// // #else
// //       *_ucsra = ((*_ucsra) & ((1 << U2X0) | (1 << TXC0)));
// // #endif
// //     }
//   //   return 1;
//   // }
//   // tx_buffer_index_t i = (_tx_buffer_head + 1) % SERIAL_TX_BUFFER_SIZE;
	
//   // If the output buffer is full, there's nothing for it other than to 
//   // wait for the interrupt handler to empty it a bit
//   // while (i == _tx_buffer_tail) {
//   //   if (bit_is_clear(SREG, SREG_I)) {
//       // Interrupts are disabled, so we'll have to poll the data
//       // register empty flag ourselves. If it is set, pretend an
//       // interrupt has happened and call the handler to free up
//       // space for us.
//   //     if(bit_is_set(*_ucsra, UDRE0))
// 	// _tx_udr_empty_irq();
//   //   } else {
//       // nop, the interrupt handler will free up space for us
//   //   }
//   // }

//   // _tx_buffer[_tx_buffer_head] = c;

//   // make atomic to prevent execution of ISR between setting the
//   // head pointer and setting the interrupt flag resulting in buffer
//   // retransmission
//   // ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
//   //   _tx_buffer_head = i;
//   //   sbi(*_ucsrb, UDRIE0);
//   // }
  
//   return 1;
// }

// #endif // whole file